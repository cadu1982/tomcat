USE BancoDeDadosTomCat;
GO

CREATE TABLE TB_TOMCAT9010 (
    ID INT IDENTITY(1,1) PRIMARY KEY,
    Nome VARCHAR(50),
    Sobrenome VARCHAR(50),
    Idade INT,
    Email VARCHAR(100)
    );
GO



