USE BancoDeDadosTomCat;
GO

CREATE TABLE TB_TOMCAT004 (
    ID INT IDENTITY(1,1) PRIMARY KEY,
    Nome VARCHAR(50),
    Sobrenome VARCHAR(50),
    Idade INT,
    Email VARCHAR(100)
    );
GO



